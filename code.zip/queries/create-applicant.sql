CREATE TABLE Applicant (
SID int,
Name VARCHAR(255),
Major VARCHAR(255),
Password VARCHAR(255),
ContactInformation VARCHAR(255),
PRIMARY KEY(SID));
