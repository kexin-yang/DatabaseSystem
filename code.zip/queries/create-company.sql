CREATE TABLE Company (
Name VARCHAR(255),
Rating float,
Password VARCHAR(255),
Location VARCHAR(255),
PRIMARY KEY(Name));
