CREATE TABLE Job (
JID int,
JobTitle VARCHAR(255), 
Organization VARCHAR(255),
Division VARCHAR(255),
PositionType VARCHAR(255),
InternalStatus VARCHAR(255),
AppDeadline VARCHAR(255),
Description VARCHAR(255),
PRIMARY KEY(JID));
