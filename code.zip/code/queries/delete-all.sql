DELETE FROM Job;

DELETE FROM Applied;

DELETE FROM Company;

DELETE FROM Applicant;

DELETE FROM StudentRecord;
