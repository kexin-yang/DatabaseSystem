DROP TABLE Job;

DROP TABLE Company;

DROP TABLE Applicant;

DROP TABLE Applied;

DROP TABLE StudentRecord;
