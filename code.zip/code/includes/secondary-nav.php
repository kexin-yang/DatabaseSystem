<div class="container">
	<ul class="nav nav-pills">
	  <li class="nav-item">
	    <a class="nav-link" href="index.php">Home</a>
	  </li>
	</ul>
</div>