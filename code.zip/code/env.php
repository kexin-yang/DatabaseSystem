<?php

$mysql_user = "root";
$mysql_password = "password";
