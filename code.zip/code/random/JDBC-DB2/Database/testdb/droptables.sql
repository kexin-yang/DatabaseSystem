 DROP TABLE student;
 DROP TABLE faculty;
 DROP TABLE class;
 DROP TABLE enrolled;
